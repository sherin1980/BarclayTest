﻿using System;

using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            FileDetails objFileDetails = new FileDetails();
            List<string> verList = new List<string> { "-v", "--v", "/v", "--version" }; //Valid version arguments
            List<string> fsList = new List<string> { "-s", "--s", "/s", "--size" }; //Valid size arguments
            //Check for minimum argmuments
            if (2 <= args.Length)
            {
                //Case Insensitive comparision
                if (verList.FindIndex(x => x.Equals(args[0],StringComparison.OrdinalIgnoreCase)) != -1)
                {
                    Console.WriteLine("File Version : {0}",objFileDetails.Version(args[1]));
                }
                else if (fsList.FindIndex(x => x.Equals(args[0], StringComparison.OrdinalIgnoreCase)) != -1)
                {
                    Console.WriteLine("File Size : {0}", objFileDetails.Size(args[1]));
                }
                else
                {
                    Console.WriteLine("Invalid Arguments");
                }
            }
            else
            {
                Console.WriteLine("Insufficient Arguments");
            }
        }
    }
}
